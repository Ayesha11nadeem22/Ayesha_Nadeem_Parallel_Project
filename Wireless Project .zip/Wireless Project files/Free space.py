"""
CODE 1: Proper Free Space Path Loss Graph
=========================================
Simple realistic Free Space graph

- Open area communication
- No obstacle
- Signal smoothly decreases
"""

import numpy as np
import matplotlib.pyplot as plt

# ── Settings ──────────────────────────────────────────────
frequency_Hz = 900e6
c = 3e8

Pt_W = 1.0
Gt = 1.0
Gr = 1.0

distance_m = np.linspace(1, 5000, 1000)

# Wavelength
wavelength = c / frequency_Hz

# ── Free Space Model ──────────────────────────────────────
Pr_fs_W = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * distance_m))**2

# Convert to dBm
Pr_fs_dBm = 10 * np.log10(Pr_fs_W * 1000)

# ── Graph ─────────────────────────────────────────────────
plt.figure(figsize=(10, 6))

plt.plot(distance_m,
         Pr_fs_dBm,
         linewidth=3,
         label='Free Space Model')

# Signal quality lines
plt.axhline(-70,
            linestyle='--',
            linewidth=1.5,
            label='Good Signal (-70 dBm)')

plt.axhline(-90,
            linestyle='--',
            linewidth=1.5,
            label='Weak Signal (-90 dBm)')

# Labels
plt.xlabel('Distance (meters)', fontsize=12)
plt.ylabel('Received Power (dBm)', fontsize=12)

plt.title('Free Space Path Loss Model',
          fontsize=14)

# Notes
plt.text(3000, -55,
         'Near distance = Strong signal',
         fontsize=10)

plt.text(3000, -95,
         'Far distance = Weak signal',
         fontsize=10)

# Grid
plt.grid(True, alpha=0.4)

# Legend
plt.legend()

# Layout
plt.tight_layout()

# Save graph
plt.savefig("free_space_correct_graph.png", dpi=150)

# Show graph
plt.show()

# ── Table ─────────────────────────────────────────────────
print("=" * 55)
print(" Distance(m) | Free Space Signal(dBm)")
print("=" * 55)

for d in [100, 500, 1000, 2000, 5000]:

    fs_w = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * d))**2

    fs_dbm = 10 * np.log10(fs_w * 1000)

    print(f"{d:>10} | {fs_dbm:>23.2f}")

print("=" * 55)

print("\nGraph saved as: free_space_correct_graph.png")