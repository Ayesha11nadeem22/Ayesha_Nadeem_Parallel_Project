"""
COMPARISON OF THREE WIRELESS PROPAGATION MODELS
================================================
1. Free Space Model
2. Two-Ray Ground Reflection Model
3. Log-Normal Shadowing Model

Ye code tino models ko aik graph mein compare karega.
"""

import numpy as np
import matplotlib.pyplot as plt

# ── SETTINGS ──────────────────────────────────────────────
frequency_Hz = 900e6      # 900 MHz
c = 3e8
Pt_dBm = 23               # Transmit power
Pt_W = 10 ** ((Pt_dBm - 30) / 10)

Gt = 1.0
Gr = 1.0

ht = 30                   # Tower height
hr = 1.5                  # Mobile height

d0 = 1.0
PL_d0 = 38.5

n = 2.7                   # Urban path loss exponent
sigma = 8                 # Shadowing variation

distance_m = np.linspace(1, 5000, 1000)

# Wavelength
wavelength = c / frequency_Hz

# ── FREE SPACE MODEL ──────────────────────────────────────
Pr_fs_W = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * distance_m))**2
RSSI_fs = 10 * np.log10(Pr_fs_W * 1000)

# ── TWO-RAY GROUND MODEL ──────────────────────────────────
dc = (4 * np.pi * ht * hr) / wavelength

Pr_tworay_W = np.zeros_like(distance_m)

for i, d in enumerate(distance_m):

    if d <= dc:
        Pr_tworay_W[i] = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * d))**2
    else:
        Pr_tworay_W[i] = Pt_W * Gt * Gr * ((ht * hr) / d**2)**2

RSSI_tworay = 10 * np.log10(Pr_tworay_W * 1000 + 1e-30)

# ── LOG-NORMAL SHADOWING MODEL ────────────────────────────
np.random.seed(42)

shadowing = np.random.normal(0, sigma, len(distance_m))

PL_shadow = PL_d0 + 10 * n * np.log10(distance_m / d0) + shadowing

RSSI_shadow = Pt_dBm - PL_shadow

# ── GRAPH ─────────────────────────────────────────────────
plt.figure(figsize=(11, 6))

# Free Space
plt.plot(distance_m,
         RSSI_fs,
         linewidth=2.5,
         label='Free Space Model')

# Two-Ray
plt.plot(distance_m,
         RSSI_tworay,
         linewidth=2.5,
         label='Two-Ray Ground Model')

# Log-Normal Shadowing
plt.plot(distance_m,
         RSSI_shadow,
         linewidth=1.8,
         alpha=0.9,
         label='Log-Normal Shadowing')

# Signal quality lines
plt.axhline(-70,
            linestyle='--',
            linewidth=1,
            label='Good Signal (-70 dBm)')

plt.axhline(-90,
            linestyle='--',
            linewidth=1,
            label='Weak Signal (-90 dBm)')

# Crossover line
plt.axvline(dc,
            linestyle=':',
            linewidth=2,
            label=f'Two-Ray Crossover ({dc:.0f} m)')

# Labels
plt.xlabel('Distance (meters)', fontsize=12)
plt.ylabel('Received Signal Strength RSSI (dBm)', fontsize=12)

plt.title('Comparison of Wireless Propagation Models',
          fontsize=14)

plt.grid(True, alpha=0.35)
plt.legend()
plt.tight_layout()

# Save graph
plt.savefig("comparison_models.png", dpi=150)

# Show graph
plt.show()

# ── COMPARISON TABLE ──────────────────────────────────────
print("=" * 85)
print(" Distance | Free Space | Two-Ray Ground | Log-Normal Shadowing")
print("=" * 85)

for d in [10, 100, 500, 1000, 2000, 5000]:

    # Free Space
    fs_w = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * d))**2
    fs_dbm = 10 * np.log10(fs_w * 1000)

    # Two-Ray
    if d <= dc:
        tr_w = fs_w
    else:
        tr_w = Pt_W * Gt * Gr * ((ht * hr) / d**2)**2

    tr_dbm = 10 * np.log10(tr_w * 1000 + 1e-30)

    # Log-Normal
    pl = PL_d0 + 10 * n * np.log10(d / d0)
    ln_dbm = Pt_dBm - pl

    print(f"{d:>8} | {fs_dbm:>10.2f} | {tr_dbm:>15.2f} | {ln_dbm:>21.2f}")

print("=" * 85)

print("\nMODEL DIFFERENCE:")
print("1. Free Space → Smooth signal decrease in open area")
print("2. Two-Ray → Faster signal reduction due to ground reflection")
print("3. Log-Normal → Random signal fluctuations caused by buildings and obstacles")

print("\nGraph saved as: comparison_models.png")