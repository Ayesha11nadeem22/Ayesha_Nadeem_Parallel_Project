"""
URBAN vs RURAL - COMBINED GRAPH
================================
1 Figure mein:
✔ RSSI Line Graph
✔ Coverage Bar Chart
"""

import numpy as np
import matplotlib.pyplot as plt

np.random.seed(42)

# ── SETTINGS ─────────────────────────────
tx_power = 30
d0 = 1
distances = np.linspace(1, 2000, 500)

# ── ENVIRONMENTS ─────────────────────────
environments = {
    "Rural": {"n": 2.1, "color": "green"},
    "Urban": {"n": 3.5, "color": "red"}
}

# ── PATH LOSS ────────────────────────────
def path_loss(d, n):
    return 20 * np.log10(d / d0) * n

# ── STORE RESULTS ────────────────────────
results = {}
coverage_values = []

for env, val in environments.items():

    n = val["n"]

    RSSI = tx_power - path_loss(distances, n)

    valid = np.where(RSSI >= -80)[0]
    coverage = distances[valid[-1]] if len(valid) > 0 else 0

    results[env] = {
        "RSSI": RSSI,
        "color": val["color"],
        "coverage": coverage
    }

    coverage_values.append(coverage)

# ─────────────────────────────────────────
# SINGLE FIGURE WITH 2 SUBPLOTS
# ─────────────────────────────────────────
fig, axes = plt.subplots(1, 2, figsize=(12, 5))

# =========================
# 1️⃣ LINE GRAPH (RSSI)
# =========================
ax = axes[0]

for env in environments:

    ax.plot(
        distances,
        results[env]["RSSI"],
        linewidth=2.5,
        label=env,
        color=environments[env]["color"]
    )

ax.axhline(-70, linestyle="--", label="Good Signal")
ax.axhline(-80, linestyle="--", label="Weak Signal")

ax.set_title("RSSI vs Distance")
ax.set_xlabel("Distance (m)")
ax.set_ylabel("RSSI (dBm)")
ax.grid(True, alpha=0.3)
ax.legend()

# =========================
# 2️⃣ BAR CHART (COVERAGE)
# =========================
ax = axes[1]

labels = list(environments.keys())
colors = [environments[e]["color"] for e in labels]

bars = ax.bar(labels, coverage_values, color=colors)

# values on bars
for i, v in enumerate(coverage_values):
    ax.text(i, v + 20, f"{v:.0f} m",
            ha='center', fontweight='bold')

ax.set_title("Coverage Comparison")
ax.set_ylabel("Distance (m)")
ax.grid(axis='y', alpha=0.3)

# ─────────────────────────────────────────
plt.tight_layout()
plt.show()