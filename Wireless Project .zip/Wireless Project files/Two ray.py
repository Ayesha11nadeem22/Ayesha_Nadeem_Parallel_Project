"""
CODE 2: Proper Two-Ray Ground Reflection Graph
==============================================
Is graph mein Two-Ray ka realistic behavior show hoga:
- Near distance → Free Space jaisa
- Far distance → Reflection ki wajah se fast drop
"""

import numpy as np
import matplotlib.pyplot as plt

# ── Settings ──────────────────────────────────────────────
frequency_Hz = 900e6
c = 3e8

Pt_W = 1.0
Gt = 1.0
Gr = 1.0

ht = 30      # Tower height
hr = 1.5     # Mobile height

distance_m = np.linspace(1, 5000, 1000)

# Wavelength
wavelength = c / frequency_Hz

# ── Free Space Model ──────────────────────────────────────
Pr_fs_W = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * distance_m))**2
Pr_fs_dBm = 10 * np.log10(Pr_fs_W * 1000)

# ── Two-Ray Ground Reflection Model ──────────────────────
# Crossover distance
dc = (4 * np.pi * ht * hr) / wavelength

Pr_tworay_W = np.zeros_like(distance_m)

for i, d in enumerate(distance_m):

    # Near region → Free Space
    if d <= dc:
        Pr_tworay_W[i] = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * d))**2

    # Far region → Two-Ray
    else:
        Pr_tworay_W[i] = Pt_W * Gt * Gr * ((ht * hr) / d**2)**2

Pr_tworay_dBm = 10 * np.log10(Pr_tworay_W * 1000 + 1e-30)

# ── Graph ─────────────────────────────────────────────────
plt.figure(figsize=(10, 6))

plt.plot(distance_m, Pr_fs_dBm,
         label='Free Space Model',
         linewidth=2.5)

plt.plot(distance_m, Pr_tworay_dBm,
         label='Two-Ray Ground Model',
         linewidth=2.5)

# Signal quality lines
plt.axhline(-70, linestyle='--', linewidth=1,
            label='Good Signal (-70 dBm)')

plt.axhline(-90, linestyle='--', linewidth=1,
            label='Weak Signal (-90 dBm)')

# Crossover distance line
plt.axvline(dc, linestyle=':',
            linewidth=2,
            label=f'Crossover Distance = {dc:.0f} m')

plt.xlabel('Distance (meters)', fontsize=12)
plt.ylabel('Received Power (dBm)', fontsize=12)

plt.title('Free Space vs Two-Ray Ground Reflection Model',
          fontsize=14)

plt.grid(True, alpha=0.4)
plt.legend()
plt.tight_layout()

plt.savefig("two_ray_correct_graph.png", dpi=150)
plt.show()

# ── Table ─────────────────────────────────────────────────
print("=" * 60)
print(" Distance(m) | Free Space(dBm) | Two-Ray(dBm)")
print("=" * 60)

for d in [100, 500, 1000, 2000, 5000]:

    fs_w = Pt_W * Gt * Gr * (wavelength / (4 * np.pi * d))**2
    fs_dbm = 10 * np.log10(fs_w * 1000)

    if d <= dc:
        tr_w = fs_w
    else:
        tr_w = Pt_W * Gt * Gr * ((ht * hr) / d**2)**2

    tr_dbm = 10 * np.log10(tr_w * 1000 + 1e-30)

    print(f"{d:>10} | {fs_dbm:>16.2f} | {tr_dbm:>13.2f}")

print("=" * 60)

print("\nGraph saved as: two_ray_correct_graph.png")