"""
CODE 3: Proper Log-Normal Shadowing Model
=========================================
Ye graph realistic wireless environment show karta hai
jahan buildings, walls aur obstacles signal ko affect karte hain.

Sirf Log-Normal Shadowing Model ka clean aur proper graph.
"""

import numpy as np
import matplotlib.pyplot as plt

# ── Same random values every run ──────────────────────────
np.random.seed(42)

# ── Parameters ────────────────────────────────────────────
Pt_dBm = 23          # Transmit power
d0 = 1.0             # Reference distance (meter)
PL_d0 = 38.5         # Path loss at d0
n = 2.7              # Urban environment exponent
sigma = 8            # Shadowing standard deviation

# Distance values
distance_m = np.linspace(1, 1000, 500)

# ── Log-Normal Shadowing Formula ──────────────────────────
# PL(d) = PL(d0) + 10*n*log10(d/d0) + X_sigma

# Random shadowing effect
shadowing = np.random.normal(0, sigma, len(distance_m))

# Path Loss
PL_shadowing = PL_d0 + 10 * n * np.log10(distance_m / d0) + shadowing

# RSSI / Received Signal Strength
RSSI_shadowing = Pt_dBm - PL_shadowing

# Average path loss line (without randomness)
PL_average = PL_d0 + 10 * n * np.log10(distance_m / d0)
RSSI_average = Pt_dBm - PL_average

# ── Graph ─────────────────────────────────────────────────
plt.figure(figsize=(10, 6))

# Realistic fluctuating signal
plt.plot(distance_m,
         RSSI_shadowing,
         linewidth=1.8,
         label='Log-Normal Shadowing Signal')

# Average trend line
plt.plot(distance_m,
         RSSI_average,
         linestyle='--',
         linewidth=2.5,
         label='Average Signal Trend')

# Signal quality lines
plt.axhline(-70,
            linestyle=':',
            linewidth=1.5,
            label='Good Signal (-70 dBm)')

plt.axhline(-90,
            linestyle=':',
            linewidth=1.5,
            label='Weak Signal (-90 dBm)')

# Labels
plt.xlabel('Distance (meters)', fontsize=12)
plt.ylabel('Received Signal Strength RSSI (dBm)', fontsize=12)

plt.title('Log-Normal Shadowing Model\nUrban Wireless Environment',
          fontsize=14)

plt.grid(True, alpha=0.35)
plt.legend()
plt.tight_layout()

# Save graph
plt.savefig("log_normal_shadowing_graph.png", dpi=150)

# Show graph
plt.show()

# ── Table Output ──────────────────────────────────────────
print("=" * 60)
print(" Distance(m) | Average RSSI(dBm)")
print("=" * 60)

for d in [10, 50, 100, 300, 500, 1000]:

    PL = PL_d0 + 10 * n * np.log10(d / d0)
    RSSI = Pt_dBm - PL

    print(f"{d:>10} | {RSSI:>18.2f}")

print("=" * 60)

print("\nExplanation:")
print("- Signal randomly fluctuates up and down due to obstacles")
print("- As distance increases, the average signal becomes weaker")
print("- This represents a real urban (city) wireless environment")

print("\nGraph saved as: log_normal_shadowing_graph.png")